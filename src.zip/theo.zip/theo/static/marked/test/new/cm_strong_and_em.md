So *a* single *word* followed *b*y *a*nother

So **a** single **word** followed **b**y **a**nother

So _a_ single _word_ followed _b_y _a_nother

So __a__ single __word__ followed __b__y __a__nother
