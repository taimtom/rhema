`someone@example.com`

``*test`*