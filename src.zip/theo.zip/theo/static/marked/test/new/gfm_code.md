``` js
var a = 'hello';
console.log(a + ' world');
```

~~~bash
echo "hello, ${WORLD}"
~~~

```````longfence
Q: What do you call a tall person who sells stolen goods?
```````

~~~~~~~~~~  ManyTildes
A longfence!
~~~~~~~~~~

How about an empty code block?

```js
```

How about a code block with only an empty line?

```js

```

With some trailing empty lines:

```
ciao


```

Closing fences must lay on a new line:

```
hello()
^```
"this should still be in the code block!"
```
