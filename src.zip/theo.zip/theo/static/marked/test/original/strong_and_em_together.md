***This is strong and em.***

So is ***this*** word.

___This is strong and em.___

So is ___this___ word.
