"""theo URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path,include
from django.contrib import admin
from django.views.generic import TemplateView
from django.contrib.auth.views import LoginView
from django.conf import settings
from django.conf.urls.static import static

from myprofile.views import ProfileFollowToggle,RegisterView,activate_user_view
from rhema.views import HomeView
from search.views import SearchView

app_name='comments'
urlpatterns = [
    path('admin/', admin.site.urls),
    path('about/', TemplateView.as_view(template_name='about.html'),name='about'),
    path('activate/<code>{a-z0-9}/', activate_user_view, name='activate'),
    path('', HomeView.as_view(), name='home'),
    path('seach/', SearchView.as_view(), name='search'),
    path('profile-follow/', ProfileFollowToggle.as_view(), name='follow'),
    path('register/', RegisterView.as_view(), name='register'),
    path('rhema/', include('rhema.urls')),
    path('comments/', include('comments.urls',namespace='comment')),
    path('music/', include('music.urls')),
    path('videos/', include('videos.urls')),
    path('u/', include('myprofile.urls',namespace='myprofile')),
    path('', include('django.contrib.auth.urls')),
  
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

