from django.apps import AppConfig


class RhemaConfig(AppConfig):
    name = 'rhema'
