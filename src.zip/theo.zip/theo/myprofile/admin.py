#from .models import MyProfile
#from django.contrib import admin



#admin.site.register(Myprofile)
