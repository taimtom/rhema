---
sanitize: true
---
[URL](javascript:alert)

[URL](vbscript:alert)

[URL](javascript&colon;alert&#40;1&#41;)

[URL](javascript&#58document;alert&#40;1&#41;)

[URL](data:text/html;base64,PHNjcmlwdD5hbGVydCgnWFNTJyk8L3NjcmlwdD4K)
